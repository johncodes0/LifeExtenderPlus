package se2017.lex;

/**
 * Created by Kevin on 3/26/2017.
 * Stores information about goals as class objects
 */

public class GoalObjects {
    public int c;
    public int t;
    public String n;

    public GoalObjects(int cur, int tar, String nam)
    {
        this.c = cur;
        this.t = tar;
        this.n = nam;
    }


}
